package com.blackmart.blackmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlackMartApplicationTests {

	@Test
	void contextLoads() {
	}

}
