package com.blackmart.blackmart.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
public class ChatbotController {
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    @PostMapping
    public Map<String, String> chat(@RequestBody Map<String, String> body) {
        String message = body.getOrDefault("message", "").trim();
        if (message.isEmpty() || message.length() > 1000) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please enter a message (maximum 1000 characters).");
        }
        String apiKey = System.getenv("OPENAI_API_KEY");
        if (apiKey == null || apiKey.isBlank()) {
            return Map.of("reply", localReply(message));
        }
        try {
            String prompt = "You are BlackMart's friendly shopping assistant. Help with product discovery, shopping, offers, cart, checkout and general store questions. Do not invent stock, prices, order status or offers; explain that customers should check the website for current details. Keep answers concise and friendly. Customer: " + message;
            String requestJson = mapper.writeValueAsString(Map.of(
                    "model", System.getenv().getOrDefault("OPENAI_MODEL", "gpt-4.1-mini"),
                    "messages", new Object[]{Map.of("role", "system", "content", "You are BlackMart AI Assistant. Be helpful, concise, and honest about unknown store data."), Map.of("role", "user", "content", prompt)},
                    "temperature", 0.4
            ));
            HttpRequest request = HttpRequest.newBuilder(URI.create("https://api.openai.com/v1/chat/completions"))
                    .timeout(Duration.ofSeconds(30)).header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(requestJson)).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) throw new IllegalStateException("AI service returned " + response.statusCode());
            JsonNode root = mapper.readTree(response.body());
            String reply = root.path("choices").path(0).path("message").path("content").asText();
            if (reply.isBlank()) throw new IllegalStateException("Empty AI response");
            return Map.of("reply", reply);
        } catch (Exception e) {
            return Map.of("reply", "Sorry, the AI assistant is temporarily unavailable. Please try again, or ask me about shopping on BlackMart.");
        }
    }

    private String localReply(String message) {
        String q = message.toLowerCase();
        if (q.contains("hello") || q.contains("hi") || q.contains("vanakkam")) return "Hi! 👋 Welcome to BlackMart. I can help you find products, understand how to shop, or navigate the website. What are you looking for?";
        if (q.contains("product") || q.contains("search") || q.contains("find") || q.contains("buy")) return "You can browse available items on the Products page. Use the product categories and search options to find what you need.";
        if (q.contains("price") || q.contains("offer") || q.contains("discount") || q.contains("sale")) return "Please check the Products page for current prices and any active offers. I don't want to give you an incorrect price or discount.";
        if (q.contains("order") || q.contains("delivery") || q.contains("track")) return "Open My Orders after logging in to review your orders. I can't verify a live order status from this chat yet.";
        if (q.contains("cart") || q.contains("checkout") || q.contains("payment")) return "Add the products you want to your Cart, then open Checkout to continue. Please review your order details before placing it.";
        if (q.contains("thank")) return "You're welcome! 😊 Happy shopping with BlackMart.";
        return "I'm BlackMart Assistant! I can help with finding products, prices and offers, cart/checkout, and My Orders. For more open-ended AI answers, set the OPENAI_API_KEY environment variable on the server.";
    }
}
