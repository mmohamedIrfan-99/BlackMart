package com.blackmart.blackmart.repository;

import com.blackmart.blackmart.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {

    List<Order> findTop5ByOrderByOrderDateDesc();

}