(() => {
  if (document.getElementById('bm-chat-launcher')) return;
  const style = document.createElement('link');
  style.rel = 'stylesheet'; style.href = 'css/chatbot.css'; document.head.appendChild(style);
  const launcher = document.createElement('button');
  launcher.id = 'bm-chat-launcher'; launcher.type = 'button'; launcher.setAttribute('aria-label','Open BlackMart AI Assistant'); launcher.innerHTML = '💬';
  const panel = document.createElement('section'); panel.id = 'bm-chat-panel'; panel.setAttribute('aria-label','BlackMart AI Assistant');
  panel.innerHTML = `<div class="bm-chat-head"><div><strong>BlackMart AI</strong><small>Shopping assistant</small></div><button id="bm-chat-close" aria-label="Close chat">×</button></div><div id="bm-chat-messages" aria-live="polite"><div class="bm-chat-bubble bm-bot">Hi! 👋 I'm BlackMart Assistant. How can I help you today?</div></div><form id="bm-chat-form"><input id="bm-chat-input" maxlength="1000" autocomplete="off" placeholder="Ask about shopping..." aria-label="Message" required><button type="submit" aria-label="Send message">➤</button></form><div class="bm-chat-note">AI responses may be inaccurate. Check product details on the site.</div>`;
  document.body.append(launcher, panel);
  const messages = panel.querySelector('#bm-chat-messages');
  const input = panel.querySelector('#bm-chat-input');
  const add = (text, who) => { const el = document.createElement('div'); el.className = `bm-chat-bubble ${who}`; el.textContent = text; messages.appendChild(el); messages.scrollTop = messages.scrollHeight; return el; };
  launcher.addEventListener('click', () => { panel.classList.toggle('bm-open'); if(panel.classList.contains('bm-open')) input.focus(); });
  panel.querySelector('#bm-chat-close').addEventListener('click', () => panel.classList.remove('bm-open'));
  panel.querySelector('#bm-chat-form').addEventListener('submit', async e => {
    e.preventDefault(); const message = input.value.trim(); if (!message) return;
    add(message, 'bm-user'); input.value = ''; input.disabled = true;
    const waiting = add('Thinking…', 'bm-bot');
    try {
      const response = await fetch('/api/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({message})});
      const data = await response.json(); waiting.textContent = response.ok ? (data.reply || 'Sorry, I could not answer that.') : 'Sorry, something went wrong. Please try again.';
    } catch (_) { waiting.textContent = 'Could not connect to BlackMart. Please check that the website server is running.'; }
    finally { input.disabled = false; input.focus(); messages.scrollTop = messages.scrollHeight; }
  });
})();
