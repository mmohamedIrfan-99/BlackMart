let cart = JSON.parse(localStorage.getItem("blackmartCart")) || [];

const buttons = document.querySelectorAll(".product-card button");

buttons.forEach((button) => {

    button.addEventListener("click", () => {

        const card = button.parentElement;

        const name = card.querySelector("h3").innerText;

        const priceText = card.querySelector(".price").innerText;

        const price = parseFloat(
            priceText.replace("₹", "").replace(",", "")
        );

        const existingProduct = cart.find(
            product => product.name === name
        );

        if (existingProduct) {

            existingProduct.quantity++;

        } else {

            cart.push({
                name: name,
                price: price,
                quantity: 1
            });

        }

        localStorage.setItem(
            "blackmartCart",
            JSON.stringify(cart)
        );

        alert(name + " added to cart! 🛒");

    });

});




const cartContainer =
    document.getElementById("cartContainer");

if (cartContainer) {

    displayCart();

}

function displayCart() {

    cartContainer.innerHTML = "";

    if (cart.length === 0) {

        cartContainer.innerHTML = `
            <h2>Your cart is empty 😔</h2>

            <p>
                Add some products to your cart!
            </p>
        `;

        return;
    }

    let total = 0;

    cart.forEach((product, index) => {

        const itemTotal =
            product.price * product.quantity;

        total += itemTotal;

        cartContainer.innerHTML += `

            <div class="cart-item">

                <div>

                    <h3>
                        ${product.name}
                    </h3>

                    <p>
                        ₹${product.price.toLocaleString()}
                        × ${product.quantity}
                    </p>

                </div>

                <div>

                    <strong>
                        ₹${itemTotal.toLocaleString()}
                    </strong>

                    <br><br>

                    <button
                        class="remove-btn"
                        onclick="removeItem(${index})">

                        Remove

                    </button>

                </div>

            </div>

        `;

    });


    cartContainer.innerHTML += `

        <div class="cart-total">

            Total:
            ₹${total.toLocaleString()}

            <br><br>

            <button
                class="checkout-btn">

                Proceed to Checkout 💳

            </button>

        </div>

    `;
}


function removeItem(index) {

    cart.splice(index, 1);

    localStorage.setItem(
        "blackmartCart",
        JSON.stringify(cart)
    );

    displayCart();

}





// ===============================
// REGISTER SYSTEM
// ===============================

const registerForm =
    document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();

            const name =
                document.getElementById(
                    "registerName"
                ).value;

            const email =
                document.getElementById(
                    "registerEmail"
                ).value;

            const password =
                document.getElementById(
                    "registerPassword"
                ).value;

            const confirmPassword =
                document.getElementById(
                    "confirmPassword"
                ).value;


            if (password !== confirmPassword) {

                alert(
                    "Passwords do not match! ❌"
                );

                return;
            }


            const user = {

                name: name,

                email: email,

                password: password

            };


            localStorage.setItem(
                "blackmartUser",
                JSON.stringify(user)
            );


            alert(
                "Account created successfully! 🎉"
            );


            window.location.href =
                "login.html";

        }
    );
}


// ===============================
// LOGIN SYSTEM
// ===============================

const loginForm =
    document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();


            const email =
                document.getElementById(
                    "loginEmail"
                ).value;

            const password =
                document.getElementById(
                    "loginPassword"
                ).value;


            const savedUser =
                JSON.parse(
                    localStorage.getItem(
                        "blackmartUser"
                    )
                );


            if (!savedUser) {

                alert(
                    "No account found. Please register first! ❌"
                );

                return;
            }


            if (
                email === savedUser.email &&
                password === savedUser.password
            ) {

                localStorage.setItem(
                    "blackmartLoggedIn",
                    "true"
                );


                alert(
                    "Login successful! 🎉"
                );


                window.location.href =
                    "index.html";

            } else {

                alert(
                    "Invalid email or password! ❌"
                );

            }

        }
    );
}





// ===============================
// CHECKOUT SYSTEM
// ===============================

const checkoutForm =
    document.getElementById("checkoutForm");

const checkoutItems =
    document.getElementById("checkoutItems");

const checkoutTotal =
    document.getElementById("checkoutTotal");


if (checkoutItems) {

    displayCheckout();

}


function displayCheckout() {

    checkoutItems.innerHTML = "";

    let total = 0;


    if (cart.length === 0) {

        checkoutItems.innerHTML = `
            <p>
                Your cart is empty.
            </p>
        `;

        checkoutTotal.innerText = "Total: ₹0";

        return;
    }


    cart.forEach((product) => {

        const itemTotal =
            product.price * product.quantity;

        total += itemTotal;


        checkoutItems.innerHTML += `

            <div class="checkout-item">

                <div>

                    <strong>
                        ${product.name}
                    </strong>

                    <p>
                        Quantity:
                        ${product.quantity}
                    </p>

                </div>

                <strong>
                    ₹${itemTotal.toLocaleString()}
                </strong>

            </div>

        `;

    });


    checkoutTotal.innerText =
        "Total: ₹" + total.toLocaleString();

}


// ===============================
// PLACE ORDER
// ===============================

if (checkoutForm) {

    checkoutForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();


            if (cart.length === 0) {

                alert(
                    "Your cart is empty! 🛒"
                );

                return;
            }


            const name =
                document.getElementById(
                    "customerName"
                ).value;

            const phone =
                document.getElementById(
                    "customerPhone"
                ).value;

            const address =
                document.getElementById(
                    "customerAddress"
                ).value;

            const city =
                document.getElementById(
                    "customerCity"
                ).value;

            const pincode =
                document.getElementById(
                    "customerPincode"
                ).value;


            const payment =
                document.querySelector(
                    'input[name="payment"]:checked'
                ).value;


            let total = 0;


            cart.forEach((product) => {

                total +=
                    product.price *
                    product.quantity;

            });


            const orderId =
                "LM" +
                Date.now();


            const order = {

                orderId: orderId,

                name: name,

                phone: phone,

                address: address,

                city: city,

                pincode: pincode,

                payment: payment,

                products: cart,

                total: total,

                date:
                    new Date().toLocaleString()

            };


            let orders =
                JSON.parse(
                   localStorage.getItem("blackmartOrders")
                ) || [];

            orders.push(order);

            localStorage.setItem(
                "blackmartOrders",
             JSON.stringify(orders)
           );  

            // Clear cart

            localStorage.removeItem(
                "blackmartCart"
            );


            alert(
                "Order placed successfully! 🎉"
            );


            window.location.href =
                "order-success.html";

        }
    );

}






// ===============================
// ORDER SUCCESS PAGE
// ===============================

const orderDetails =
    document.getElementById("orderDetails");


if (orderDetails) {

    const savedOrder =
        JSON.parse(
            localStorage.getItem(
                "blackmartOrder"
            )
        );


    if (savedOrder) {

        orderDetails.innerHTML = `

            <div class="order-info">

                <p>
                    <strong>Order ID:</strong>
                    ${savedOrder.orderId}
                </p>

                <p>
                    <strong>Name:</strong>
                    ${savedOrder.name}
                </p>

                <p>
                    <strong>Phone:</strong>
                    ${savedOrder.phone}
                </p>

                <p>
                    <strong>Address:</strong>
                    ${savedOrder.address},
                    ${savedOrder.city} -
                    ${savedOrder.pincode}
                </p>

                <p>
                    <strong>Payment:</strong>
                    ${savedOrder.payment}
                </p>

                <p>
                    <strong>Total:</strong>
                    ₹${savedOrder.total.toLocaleString()}
                </p>

                <p>
                    <strong>Order Date:</strong>
                    ${savedOrder.date}
                </p>

            </div>

        `;

    } else {

        orderDetails.innerHTML = `
            <p>
                No recent order found.
            </p>
        `;

    }

}





// ===============================
// MY ORDERS
// ===============================

const ordersContainer =
    document.getElementById("ordersContainer");


if (ordersContainer) {

    displayOrders();

}


function displayOrders() {

    const orders =
        JSON.parse(
            localStorage.getItem("blackmartOrders")
        ) || [];


    if (orders.length === 0) {

        ordersContainer.innerHTML = `

            <div class="no-orders">

                <h2>
                    No Orders Yet 😔
                </h2>

                <p>
                    You haven't placed any orders.
                </p>

                <br>

                <a
                    href="products.html"
                    class="shop-btn">

                    Start Shopping 🛍️

                </a>

            </div>

        `;

        return;
    }


    ordersContainer.innerHTML = "";


    orders.forEach((order) => {

        let productsHTML = "";


        order.products.forEach((product) => {

            const itemTotal =
                product.price *
                product.quantity;


            productsHTML += `

                <div class="order-product">

                    <span>

                        ${product.name}
                        × ${product.quantity}

                    </span>

                    <strong>

                        ₹${itemTotal.toLocaleString()}

                    </strong>

                </div>

            `;

        });


        ordersContainer.innerHTML += `

            <div class="order-card">

                <div class="order-header">

                    <span class="order-id">

                        Order ID:
                        ${order.orderId}

                    </span>

                    <span class="order-status">

                        ✓ Order Placed

                    </span>

                </div>


                ${productsHTML}


                <p>
                    <strong>Payment:</strong>
                    ${order.payment}
                </p>

                <p>
                    <strong>Delivery:</strong>
                    ${order.city} -
                    ${order.pincode}
                </p>

                <p>
                    <strong>Date:</strong>
                    ${order.date}
                </p>


                <div class="order-total">

                    Total:
                    ₹${order.total.toLocaleString()}

                </div>

            </div>

        `;

    });

}





// ===============================
// ADMIN DASHBOARD
// ===============================

const totalProductsElement =
    document.getElementById("totalProducts");

const totalOrdersElement =
    document.getElementById("totalOrders");

const totalUsersElement =
    document.getElementById("totalUsers");

const totalSalesElement =
    document.getElementById("totalSales");


if (totalProductsElement) {

    // Current demo products

    const productsCount = 8;

    totalProductsElement.innerText =
        productsCount;


    // Orders

    const orders =
        JSON.parse(
            localStorage.getItem("blackmartOrders")
        ) || [];

    totalOrdersElement.innerText =
        orders.length;


    // Users

    const user =
        localStorage.getItem("blackmartUser");

    totalUsersElement.innerText =
        user ? 1 : 0;


    // Sales

    let sales = 0;

    orders.forEach((order) => {

        sales += order.total;

    });

    totalSalesElement.innerText =
        "₹" + sales.toLocaleString();

}


// ===============================
// ADMIN LOGOUT
// ===============================

function adminLogout() {

    localStorage.removeItem(
        "blackmartAdminLoggedIn"
    );

    alert(
        "Admin logged out successfully!"
    );

    window.location.href =
        "index.html";
}




// ===============================
// ADMIN PRODUCT MANAGEMENT
// ===============================

const productForm =
    document.getElementById("productForm");

const adminProductList =
    document.getElementById("adminProductList");


// Default Products

let adminProducts =
    JSON.parse(
        localStorage.getItem("blackmartProducts")
    );


if (!adminProducts) {

    adminProducts = [

        {
            id: 101,
            name: "Laptop",
            price: 55000,
            category: "Electronics",
            stock: 10
        },

        {
            id: 102,
            name: "Mobile Phone",
            price: 25000,
            category: "Electronics",
            stock: 15
        },

        {
            id: 103,
            name: "Headphones",
            price: 1500,
            category: "Accessories",
            stock: 25
        },

        {
            id: 104,
            name: "Smart Watch",
            price: 3000,
            category: "Accessories",
            stock: 20
        },

        {
            id: 105,
            name: "Keyboard",
            price: 1200,
            category: "Electronics",
            stock: 30
        },

        {
            id: 106,
            name: "Mouse",
            price: 700,
            category: "Electronics",
            stock: 35
        },

        {
            id: 107,
            name: "Monitor",
            price: 12000,
            category: "Electronics",
            stock: 8
        },

        {
            id: 108,
            name: "Tablet",
            price: 18000,
            category: "Electronics",
            stock: 12
        }

    ];


    localStorage.setItem(
        "blackmartProducts",
        JSON.stringify(adminProducts)
    );

}


if (adminProductList) {

    displayAdminProducts();

}


// Display Products

function displayAdminProducts(
    searchText = ""
) {

    adminProductList.innerHTML = "";


    const filteredProducts =
        adminProducts.filter(
            product =>
                product.name
                    .toLowerCase()
                    .includes(
                        searchText.toLowerCase()
                    )
        );


    filteredProducts.forEach(
        (product) => {

            adminProductList.innerHTML += `

                <tr>

                    <td>
                        ${product.id}
                    </td>

                    <td>
                        ${product.name}
                    </td>

                    <td>
                        ${product.category}
                    </td>

                    <td>
                        ₹${product.price.toLocaleString()}
                    </td>

                    <td>
                        ${product.stock}
                    </td>

                    <td>

                        <button
                            class="edit-btn"
                            onclick="editProduct(${product.id})">

                            Edit ✏️

                        </button>


                        <button
                            class="delete-btn"
                            onclick="deleteProduct(${product.id})">

                            Delete 🗑️

                        </button>

                    </td>

                </tr>

            `;

        }
    );

}


// Add Product

if (productForm) {

    productForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();


            const name =
                document.getElementById(
                    "productName"
                ).value;


            const price =
                Number(
                    document.getElementById(
                        "productPrice"
                    ).value
                );


            const category =
                document.getElementById(
                    "productCategory"
                ).value;


            const stock =
                Number(
                    document.getElementById(
                        "productStock"
                    ).value
                );


            const editId =
                document.getElementById(
                    "editProductId"
                ).value;


            // EDIT

            if (editId) {

                const product =
                    adminProducts.find(
                        p =>
                            p.id ===
                            Number(editId)
                    );


                product.name =
                    name;

                product.price =
                    price;

                product.category =
                    category;

                product.stock =
                    stock;


                alert(
                    "Product updated successfully! ✅"
                );

            }


            // ADD

            else {

                const newProduct = {

                    id:
                        Date.now(),

                    name:
                        name,

                    price:
                        price,

                    category:
                        category,

                    stock:
                        stock

                };


                adminProducts.push(
                    newProduct
                );


                alert(
                    "Product added successfully! 🎉"
                );

            }


            localStorage.setItem(
                "blackmartProducts",
                JSON.stringify(
                    adminProducts
                )
            );


            productForm.reset();

            document.getElementById(
                "editProductId"
            ).value = "";


            displayAdminProducts();

        }
    );

}


// Edit Product

function editProduct(id) {

    const product =
        adminProducts.find(
            p => p.id === id
        );


    if (!product) return;


    document.getElementById(
        "productName"
    ).value =
        product.name;


    document.getElementById(
        "productPrice"
    ).value =
        product.price;


    document.getElementById(
        "productCategory"
    ).value =
        product.category;


    document.getElementById(
        "productStock"
    ).value =
        product.stock;


    document.getElementById(
        "editProductId"
    ).value =
        product.id;


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


// Delete Product

function deleteProduct(id) {

    const confirmDelete =
        confirm(
            "Are you sure you want to delete this product?"
        );


    if (!confirmDelete) return;


    adminProducts =
        adminProducts.filter(
            product =>
                product.id !== id
        );


    localStorage.setItem(
        "blackmartProducts",
        JSON.stringify(
            adminProducts
        )
    );


    displayAdminProducts();


    alert(
        "Product deleted successfully! 🗑️"
    );

}


// Search Products

const adminProductSearch =
    document.getElementById(
        "adminProductSearch"
    );


if (adminProductSearch) {

    adminProductSearch.addEventListener(
        "input",
        function() {

            displayAdminProducts(
                this.value
            );

        }
    );

}




// ===============================
// CUSTOMER PRODUCT DISPLAY
// ===============================

const productContainer =
    document.getElementById("productContainer");

const searchInput =
    document.getElementById("searchInput");


if (productContainer) {

    displayCustomerProducts();

}


const CUSTOMER_API_URL = "http://localhost:8081/api/products";

const DEMO_PRODUCTS = [
    { id: 1, name: "Laptop", price: 55000, quantity: 10, category: "Electronics", imageUrl: "../src/main/resources/static/images/laptop.jpg" },
    { id: 2, name: "Smartphone", price: 25000, quantity: 15, category: "Electronics", imageUrl: "../src/main/resources/static/images/mobile.jpg" },
    { id: 3, name: "Wireless Earbuds", price: 2499, quantity: 25, category: "Electronics", imageUrl: "../src/main/resources/static/images/headphones.jpg" },
    { id: 4, name: "Bluetooth Speaker", price: 3499, quantity: 20, category: "Electronics", imageUrl: "../src/main/resources/static/images/speaker.jpg" },
    { id: 5, name: "Oversized T-Shirt", price: 799, quantity: 30, category: "Fashion", imageUrl: "" },
    { id: 6, name: "Casual Shirt", price: 1299, quantity: 20, category: "Fashion", imageUrl: "" },
    { id: 7, name: "Denim Jeans", price: 1999, quantity: 15, category: "Fashion", imageUrl: "" },
    { id: 8, name: "Hoodie", price: 1499, quantity: 18, category: "Fashion", imageUrl: "" },
    { id: 9, name: "Table Lamp", price: 899, quantity: 20, category: "Home", imageUrl: "" },
    { id: 10, name: "Water Bottle", price: 499, quantity: 35, category: "Home", imageUrl: "" },
    { id: 11, name: "Bedsheet Set", price: 1299, quantity: 15, category: "Home", imageUrl: "" },
    { id: 12, name: "Storage Box", price: 699, quantity: 25, category: "Home", imageUrl: "" },
    { id: 13, name: "Smart Watch", price: 3999, quantity: 15, category: "Accessories", imageUrl: "../src/main/resources/static/images/smartwatch.jpg" },
    { id: 14, name: "Laptop Backpack", price: 1299, quantity: 20, category: "Accessories", imageUrl: "../src/main/resources/static/images/laptop.jpg" },
    { id: 15, name: "Phone Stand", price: 399, quantity: 30, category: "Accessories", imageUrl: "../src/main/resources/static/images/mobile.jpg" },
    { id: 16, name: "USB-C Cable", price: 299, quantity: 40, category: "Accessories", imageUrl: "../src/main/resources/static/images/usb-cable.jpg" },
    { id: 17, name: "Mechanical Keyboard", price: 2499, quantity: 18, category: "Accessories", imageUrl: "../src/main/resources/static/images/keyboard.jpg" },
    { id: 18, name: "Wireless Mouse", price: 899, quantity: 25, category: "Accessories", imageUrl: "../src/main/resources/static/images/mouse.jpg" },
    { id: 19, name: "Full HD Monitor", price: 11999, quantity: 12, category: "Electronics", imageUrl: "../src/main/resources/static/images/monitor.jpg" },
    { id: 20, name: "Fast Charger", price: 999, quantity: 30, category: "Electronics", imageUrl: "../src/main/resources/static/images/charger.jpg" }
];

async function displayCustomerProducts(searchText = "") {

    let products;

    try {
        const response = await fetch(CUSTOMER_API_URL, {
            method: "GET",
            headers: { "Accept": "application/json" }
        });

        if (!response.ok) throw new Error("Backend returned " + response.status);
        products = await response.json();
        localStorage.setItem("blackmartProducts", JSON.stringify(products));
        localStorage.setItem("blackmartBackendOnline", "true");

    } catch (error) {
        console.warn("BlackMart backend is not running. Using local demo products.", error);
        products = JSON.parse(localStorage.getItem("blackmartProducts")) || DEMO_PRODUCTS;
        localStorage.setItem("blackmartProducts", JSON.stringify(products));
        localStorage.setItem("blackmartBackendOnline", "false");
    }

    productContainer.innerHTML = "";

        const filteredProducts = products.filter(
            product =>
                product.name
                    .toLowerCase()
                    .includes(searchText.toLowerCase())
        );

        if (filteredProducts.length === 0) {

            productContainer.innerHTML = `
                <div class="no-orders">

                    <h2>
                        No Products Found 😔
                    </h2>

                    <p>
                        Try another search.
                    </p>

                </div>
            `;

            return;
        }

        filteredProducts.forEach(product => {

            productContainer.innerHTML += `

                <div class="product-card">

                    <div class="product-image">
                        🛍️
                    </div>

                    <h3>
                        ${product.name}
                    </h3>

                    <p class="price">
                        ₹${product.price.toLocaleString()}
                    </p>

                    <p>
                        Stock:
                        ${product.quantity}
                    </p>

                    <button
                        onclick="addProductToCart(${product.id})"
                        ${product.quantity <= 0 ? "disabled" : ""}>

                        ${
                            product.quantity <= 0
                            ? "Out of Stock"
                            : "Add to Cart 🛒"
                        }

                    </button>

                </div>

            `;

        });

    }


// ===============================
// SEARCH
// ===============================

if (searchInput) {

    searchInput.addEventListener(
        "input",
        function() {

            displayCustomerProducts(
                this.value
            );

        }
    );

}


// ===============================
// ADD PRODUCT TO CART
// ===============================

function addProductToCart(id) {

    const products =
        JSON.parse(
            localStorage.getItem("blackmartProducts")
        ) || [];


    const product =
        products.find(
            p => p.id === id
        );


    if (!product) {

        alert(
            "Product not found! ❌"
        );

        return;
    }


    let cart =
        JSON.parse(
            localStorage.getItem("blackmartCart")
        ) || [];


    const existingProduct =
        cart.find(
            p => p.id === id
        );


    if (existingProduct) {

        if (
            existingProduct.quantity >=
            product.stock
        ) {

            alert(
                "No more stock available! ❌"
            );

            return;
        }


        existingProduct.quantity++;

    } else {

        cart.push({

            id: product.id,

            name: product.name,

            price: product.price,

            quantity: 1

        });

    }


    localStorage.setItem(
        "blackmartCart",
        JSON.stringify(cart)
    );


    alert(
        product.name +
        " added to cart! 🛒"
    );

}