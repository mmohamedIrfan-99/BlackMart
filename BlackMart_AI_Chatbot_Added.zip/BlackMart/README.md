# BlackMart

A full-stack e-commerce project using Spring Boot, JPA/H2 and a black-and-white frontend.

## IMPORTANT: How to run

### Recommended
1. Install Java 17 or newer.
2. Double-click `START_BLACKMART.bat`.
3. Wait until the backend window says Spring Boot has started.
4. The browser will open automatically at:
   `http://localhost:8081/`

### Do NOT use VS Code Live Server for the main application
If you open `frontend/products.html` using Live Server (`127.0.0.1:5500`), the browser is only serving the frontend. The Spring Boot backend still has to run separately on port 8080.

The actual full application is served by Spring Boot from:
`src/main/resources/static/`

Open:
- `http://localhost:8081/` - Home
- `http://localhost:8081/products.html` - Products
- `http://localhost:8081/cart.html` - Cart
- `http://localhost:8081/admin-login.html` - Admin login

## Backend

- Spring Boot
- Spring Data JPA
- H2 embedded database by default
- MySQL profile included as an optional configuration
- Product data is automatically inserted when the application starts

## Sample products

The application automatically creates 20 sample products including:
Laptop, Smartphone, Wireless Earbuds, Bluetooth Speaker, Oversized T-Shirt, Casual Shirt, Denim Jeans, Hoodie, Table Lamp, Water Bottle, Bedsheet Set, Storage Box, Smart Watch, Laptop Backpack, Phone Stand, USB-C Cable, Mechanical Keyboard, Wireless Mouse, Full HD Monitor and Fast Charger.

## If you still see "Unable to load products"

1. Look at the backend command window.
2. Make sure it says the Spring Boot application started successfully.
3. Visit `http://localhost:8081/api/products` in the browser.
4. You should see a JSON list of products.
5. Then open `http://localhost:8081/products.html`.

The standalone `frontend` folder also contains a local demo-product fallback, so the product page can still display sample products when the backend is temporarily unavailable. Backend mode is used automatically whenever port 8080 is available.

## Admin login

Username: `admin`
Password: `admin123`

For a college/demo project only; change these credentials before real deployment.


## BlackMart AI Chatbot

A floating shopping-assistant chat widget has been added to the existing pages without replacing existing store code. It answers common shopping questions locally by default. To enable live AI responses, set `OPENAI_API_KEY` in the server environment before starting the app. Optionally set `OPENAI_MODEL` (defaults to `gpt-4.1-mini`). Never put the API key in frontend JavaScript or commit it to Git. The chat endpoint is `POST /api/chat`.
