@echo off
setlocal
cd /d "%~dp0"

echo ===============================================
echo          BLACKMART - STARTING SERVER
echo ===============================================
echo.

where java >nul 2>nul
if errorlevel 1 (
    echo ERROR: Java is not installed or not in PATH.
    echo Install Java 17 or newer, then run this file again.
    pause
    exit /b 1
)

if not exist "mvnw.cmd" (
    echo ERROR: Maven wrapper not found.
    pause
    exit /b 1
)

start "BlackMart Backend" cmd /k "cd /d "%~dp0" && mvnw.cmd spring-boot:run"

echo Waiting for the Spring Boot backend on port 8080...
for /l %%i in (1,1,60) do (
    powershell -NoProfile -Command "$c=Test-NetConnection 127.0.0.1 -Port 8080 -WarningAction SilentlyContinue; if($c.TcpTestSucceeded){exit 0}else{exit 1}" >nul 2>nul
    if not errorlevel 1 goto READY
    timeout /t 1 /nobreak >nul
)

echo.
echo The backend did not become ready within 60 seconds.
echo Check the BlackMart Backend window for the error.
pause
exit /b 1

:READY
echo Backend is running!
echo Opening BlackMart at http://localhost:8081/
start "" "http://localhost:8081/"
exit /b 0
