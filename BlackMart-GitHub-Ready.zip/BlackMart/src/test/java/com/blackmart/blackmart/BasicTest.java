package com.blackmart.blackmart;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class BasicTest {
 @Test void projectTest(){assertEquals(2,1+1);}
}
