async function loadProducts(){
 const box=document.getElementById('products'); if(!box)return;
 try{
  const r=await fetch('api/products'); const products=await r.json();
  box.innerHTML=products.map(p=>`<article class="card"><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description||'')}</p><strong>₹${p.price}</strong><p>Stock: ${p.stock}</p><small>${escapeHtml(p.category||'')}</small></article>`).join('')||'<p>No products yet.</p>';
 }catch(e){box.innerHTML='<p>Could not load products.</p>'}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
loadProducts();
