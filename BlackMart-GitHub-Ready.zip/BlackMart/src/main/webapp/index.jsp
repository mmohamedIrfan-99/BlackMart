<%@ page import="com.blackmart.blackmart.model.User" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%
 User user=(User)session.getAttribute("user");
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><title>BlackMart</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header><h1>BlackMart</h1><nav>
<% if(user==null){ %><a href="#login">Login</a><a href="#register">Register</a><% } else { %>
<span>Hi, <%=user.getName()%></span><a href="auth">Logout</a><% } %>
</nav></header>
<main>
<section class="hero"><h2>Shop smarter with BlackMart</h2><p>Multi-seller marketplace demo.</p></section>
<section>
<h2>Products</h2>
<div id="products" class="grid"></div>
</section>
<% if(user==null){ %>
<section class="forms">
<form id="login" method="post" action="auth"><h3>Login</h3><input type="hidden" name="action" value="login"><input name="email" type="email" placeholder="Email" required><input name="password" type="password" placeholder="Password" required><button>Login</button></form>
<form id="register" method="post" action="auth"><h3>Register</h3><input type="hidden" name="action" value="register"><input name="name" placeholder="Name" required><input name="email" type="email" placeholder="Email" required><input name="password" type="password" placeholder="Password (6+)" required><button>Register</button></form>
</section>
<% } %>
</main>
<script src="js/app.js"></script>
</body>
</html>
