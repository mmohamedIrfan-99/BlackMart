package com.blackmart.blackmart.dao;
import com.blackmart.blackmart.model.Product; import com.blackmart.blackmart.util.DBUtil;
import java.sql.*; import java.util.*;
public class ProductDao {
 public List<Product> findAll(String search,String category)throws SQLException{
  String q="SELECT id,seller_id,name,description,price,stock,category,image_url,status FROM products WHERE status='APPROVED' AND (?='' OR LOWER(name) LIKE LOWER(?) OR LOWER(description) LIKE LOWER(?)) AND (?='' OR category=?) ORDER BY id DESC";
  List<Product> list=new ArrayList<>();
  try(Connection c=DBUtil.getDataSource().getConnection();PreparedStatement p=c.prepareStatement(q)){
   String s=search==null?"":search.trim(), pattern="%"+s+"%"; String cat=category==null?"":category.trim();
   p.setString(1,s);p.setString(2,pattern);p.setString(3,pattern);p.setString(4,cat);p.setString(5,cat);
   try(ResultSet r=p.executeQuery()){while(r.next())list.add(map(r));}
  } return list;
 }
 public long create(Product x)throws SQLException{
  String q="INSERT INTO products(seller_id,name,description,price,stock,category,image_url,status) VALUES(?,?,?,?,?,?,?,'APPROVED')";
  try(Connection c=DBUtil.getDataSource().getConnection();PreparedStatement p=c.prepareStatement(q,Statement.RETURN_GENERATED_KEYS)){
   p.setLong(1,x.getSellerId());p.setString(2,x.getName());p.setString(3,x.getDescription());p.setBigDecimal(4,x.getPrice());p.setInt(5,x.getStock());p.setString(6,x.getCategory());p.setString(7,x.getImageUrl());p.executeUpdate();
   try(ResultSet r=p.getGeneratedKeys()){r.next();return r.getLong(1);}
  }
 }
 public void delete(long id,long sellerId)throws SQLException{
  try(Connection c=DBUtil.getDataSource().getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM products WHERE id=? AND seller_id=?")){p.setLong(1,id);p.setLong(2,sellerId);p.executeUpdate();}
 }
 private Product map(ResultSet r)throws SQLException{Product x=new Product();x.setId(r.getLong(1));x.setSellerId(r.getLong(2));x.setName(r.getString(3));x.setDescription(r.getString(4));x.setPrice(r.getBigDecimal(5));x.setStock(r.getInt(6));x.setCategory(r.getString(7));x.setImageUrl(r.getString(8));x.setStatus(r.getString(9));return x;}
}
