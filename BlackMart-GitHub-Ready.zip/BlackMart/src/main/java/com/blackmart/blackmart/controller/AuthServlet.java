package com.blackmart.blackmart.controller;
import com.blackmart.blackmart.model.User; import com.blackmart.blackmart.service.AuthService;
import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet("/auth")
public class AuthServlet extends HttpServlet {
 private final AuthService service=new AuthService();
 protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
  String action=req.getParameter("action");
  try{
   if("register".equals(action)){service.register(req.getParameter("name"),req.getParameter("email"),req.getParameter("password"));res.sendRedirect("index.jsp?msg=registered");return;}
   if("login".equals(action)){User u=service.login(req.getParameter("email"),req.getParameter("password"));if(u==null){res.sendRedirect("index.jsp?error=login");return;}HttpSession old=req.getSession(false);if(old!=null)old.invalidate();HttpSession s=req.getSession(true);s.setAttribute("user",u);res.sendRedirect("index.jsp");return;}
  }catch(Exception e){res.sendRedirect("index.jsp?error="+java.net.URLEncoder.encode(e.getMessage(),"UTF-8"));}
 }
 @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException{req.getSession().invalidate();res.sendRedirect("index.jsp");}
}
