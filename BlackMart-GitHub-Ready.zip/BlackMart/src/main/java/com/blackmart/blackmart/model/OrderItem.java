package com.blackmart.blackmart.model;
import java.math.BigDecimal;
public class OrderItem {
    private long id,orderId,productId,sellerId; private int quantity; private BigDecimal price;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getOrderId(){return orderId;} public void setOrderId(long v){orderId=v;}
    public long getProductId(){return productId;} public void setProductId(long v){productId=v;}
    public long getSellerId(){return sellerId;} public void setSellerId(long v){sellerId=v;}
    public int getQuantity(){return quantity;} public void setQuantity(int v){quantity=v;}
    public BigDecimal getPrice(){return price;} public void setPrice(BigDecimal v){price=v;}
}
