package com.blackmart.blackmart.model;
import java.math.BigDecimal;
public class Product {
    private long id,sellerId; private String name,description,category,imageUrl,status; private BigDecimal price; private int stock;
    public Product(){}
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getSellerId(){return sellerId;} public void setSellerId(long v){sellerId=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getDescription(){return description;} public void setDescription(String v){description=v;}
    public BigDecimal getPrice(){return price;} public void setPrice(BigDecimal v){price=v;}
    public int getStock(){return stock;} public void setStock(int v){stock=v;}
    public String getCategory(){return category;} public void setCategory(String v){category=v;}
    public String getImageUrl(){return imageUrl;} public void setImageUrl(String v){imageUrl=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
}
