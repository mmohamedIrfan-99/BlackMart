package com.blackmart.blackmart.dao;
import com.blackmart.blackmart.model.User;
import com.blackmart.blackmart.util.DBUtil;
import java.sql.*;
public class UserDao {
    public User findByEmail(String email)throws SQLException{
        String q="SELECT id,name,email,password,role FROM users WHERE email=?";
        try(Connection c=DBUtil.getDataSource().getConnection();PreparedStatement p=c.prepareStatement(q)){
            p.setString(1,email); try(ResultSet r=p.executeQuery()){return r.next()?map(r):null;}
        }
    }
    public long create(User u)throws SQLException{
        String q="INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)";
        try(Connection c=DBUtil.getDataSource().getConnection();PreparedStatement p=c.prepareStatement(q,Statement.RETURN_GENERATED_KEYS)){
            p.setString(1,u.getName());p.setString(2,u.getEmail());p.setString(3,u.getPassword());p.setString(4,u.getRole());
            p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){r.next();return r.getLong(1);}
        }
    }
    private User map(ResultSet r)throws SQLException{return new User(r.getLong(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5));}
}
