package com.blackmart.blackmart.model;
public class CartItem {
    private long id,buyerId,productId; private int quantity;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getBuyerId(){return buyerId;} public void setBuyerId(long v){buyerId=v;}
    public long getProductId(){return productId;} public void setProductId(long v){productId=v;}
    public int getQuantity(){return quantity;} public void setQuantity(int v){quantity=v;}
}
