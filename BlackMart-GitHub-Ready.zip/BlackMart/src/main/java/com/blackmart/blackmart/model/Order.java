package com.blackmart.blackmart.model;
import java.math.BigDecimal; import java.sql.Timestamp;
public class Order {
    private long id,buyerId; private BigDecimal totalAmount; private String status,paymentStatus,shippingAddress; private Timestamp createdAt;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getBuyerId(){return buyerId;} public void setBuyerId(long v){buyerId=v;}
    public BigDecimal getTotalAmount(){return totalAmount;} public void setTotalAmount(BigDecimal v){totalAmount=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getPaymentStatus(){return paymentStatus;} public void setPaymentStatus(String v){paymentStatus=v;}
    public String getShippingAddress(){return shippingAddress;} public void setShippingAddress(String v){shippingAddress=v;}
    public Timestamp getCreatedAt(){return createdAt;} public void setCreatedAt(Timestamp v){createdAt=v;}
}
