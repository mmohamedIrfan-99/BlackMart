package com.blackmart.blackmart.service;
import com.blackmart.blackmart.dao.UserDao; import com.blackmart.blackmart.model.User; import org.mindrot.jbcrypt.BCrypt;
public class AuthService {
 private final UserDao dao=new UserDao();
 public User login(String email,String password)throws Exception{
  User u=dao.findByEmail(email); if(u!=null&&BCrypt.checkpw(password,u.getPassword())){u.setPassword(null);return u;} return null;
 }
 public void register(String name,String email,String password)throws Exception{
  if(name==null||name.isBlank()||email==null||email.isBlank()||password==null||password.length()<6)throw new IllegalArgumentException("Invalid registration details");
  if(dao.findByEmail(email.trim().toLowerCase())!=null)throw new IllegalArgumentException("Email already registered");
  User u=new User();u.setName(name.trim());u.setEmail(email.trim().toLowerCase());u.setPassword(BCrypt.hashpw(password,BCrypt.gensalt(12)));u.setRole("BUYER");dao.create(u);
 }
}
