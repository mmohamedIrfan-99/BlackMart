package com.blackmart.blackmart.controller;
import com.blackmart.blackmart.dao.ProductDao; import com.blackmart.blackmart.model.Product; import com.blackmart.blackmart.model.User; import com.google.gson.Gson;
import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.*; import java.math.BigDecimal;
@WebServlet("/api/products")
public class ProductServlet extends HttpServlet {
 private final ProductDao dao=new ProductDao(); private final Gson gson=new Gson();
 protected void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException{
  try{res.setContentType("application/json");res.getWriter().print(gson.toJson(dao.findAll(req.getParameter("search"),req.getParameter("category"))));}catch(Exception e){res.sendError(500);}
 }
 protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
  User u=(User)req.getSession().getAttribute("user"); if(u==null||!"SELLER".equals(u.getRole())){res.sendError(403);return;}
  try{Product p=new Product();p.setSellerId(u.getId());p.setName(req.getParameter("name"));p.setDescription(req.getParameter("description"));p.setPrice(new BigDecimal(req.getParameter("price")));p.setStock(Integer.parseInt(req.getParameter("stock")));p.setCategory(req.getParameter("category"));p.setImageUrl(req.getParameter("imageUrl"));dao.create(p);res.sendRedirect("index.jsp?msg=product-added");}catch(Exception e){res.sendError(400,e.getMessage());}
 }
}
