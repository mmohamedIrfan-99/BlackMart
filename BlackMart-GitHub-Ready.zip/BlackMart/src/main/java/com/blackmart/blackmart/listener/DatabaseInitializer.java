package com.blackmart.blackmart.listener;

import com.blackmart.blackmart.util.DBUtil;
import org.mindrot.jbcrypt.BCrypt;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.*;

@WebListener
public class DatabaseInitializer implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent event) {
        DBUtil.init();
        try (InputStream in = event.getServletContext().getResourceAsStream("/WEB-INF/schema.sql")) {
            if (in == null) throw new IllegalStateException("schema.sql not found");
            StringBuilder sql = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (!line.isEmpty() && !line.startsWith("--")) sql.append(line).append('\n');
                }
            }
            try (Connection c = DBUtil.getDataSource().getConnection();
                 Statement s = c.createStatement()) {
                for (String q : sql.toString().split(";")) {
                    if (!q.trim().isEmpty()) s.execute(q.trim());
                }
            }
            seed("admin@blackmart.local", "Admin", "admin123", "ADMIN");
            seed("seller@blackmart.local", "Demo Seller", "seller123", "SELLER");
            System.out.println("BlackMart database initialized.");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Database initialization failed", e);
        }
    }

    private void seed(String email, String name, String password, String role) throws SQLException {
        String check = "SELECT COUNT(*) FROM users WHERE email=?";
        String insert = "INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)";
        try (Connection c = DBUtil.getDataSource().getConnection();
             PreparedStatement p = c.prepareStatement(check)) {
            p.setString(1, email);
            try (ResultSet rs = p.executeQuery()) {
                rs.next();
                if (rs.getInt(1) == 0) {
                    try (PreparedStatement i = c.prepareStatement(insert)) {
                        i.setString(1, name);
                        i.setString(2, email);
                        i.setString(3, BCrypt.hashpw(password, BCrypt.gensalt(12)));
                        i.setString(4, role);
                        i.executeUpdate();
                    }
                }
            }
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
        DBUtil.close();
    }
}
