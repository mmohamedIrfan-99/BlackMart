package com.blackmart.blackmart.model;
import java.sql.Timestamp;
public class Review {
    private long id,buyerId,productId; private int rating; private String comment; private Timestamp createdAt;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getBuyerId(){return buyerId;} public void setBuyerId(long v){buyerId=v;}
    public long getProductId(){return productId;} public void setProductId(long v){productId=v;}
    public int getRating(){return rating;} public void setRating(int v){rating=v;}
    public String getComment(){return comment;} public void setComment(String v){comment=v;}
    public Timestamp getCreatedAt(){return createdAt;} public void setCreatedAt(Timestamp v){createdAt=v;}
}
