package com.blackmart.blackmart.util;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import javax.sql.DataSource;

public final class DBUtil {
    private static HikariDataSource dataSource;

    private DBUtil() {}

    public static synchronized void init() {
        if (dataSource != null) return;
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:./data/blackmart;DB_CLOSE_DELAY=-1");
        config.setUsername("sa");
        config.setPassword("");
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(2);
        config.setPoolName("BlackMartPool");
        dataSource = new HikariDataSource(config);
    }

    public static DataSource getDataSource() {
        init();
        return dataSource;
    }

    public static synchronized void close() {
        if (dataSource != null) {
            dataSource.close();
            dataSource = null;
        }
    }
}
