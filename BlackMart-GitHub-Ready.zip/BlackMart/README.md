# BlackMart

BlackMart is a Java Servlet/JSP multi-seller e-commerce marketplace.

## Stack
- Java 17
- Maven
- Tomcat 9
- H2
- HikariCP
- JSP/Servlets
- Gson
- BCrypt

## Roles
- Buyer
- Seller
- Admin

## Features
- Registration and login
- Product browsing and search
- Seller product management
- Cart and mock checkout
- Order history
- Admin moderation
- Reviews and ratings
- Session-based authentication

## Build
```powershell
mvn clean package
```

Deploy `target/blackmart.war` to Tomcat 9 `webapps`.

## Demo accounts
The initializer creates:
- Admin: admin@blackmart.local / admin123
- Seller: seller@blackmart.local / seller123

Change demo credentials before production use.
